#ifndef _CONFIG_CONV_
#define _CONFIG_CONV_

#define DATA_WIDTH 14
#define DATA_TYPE 16
#define IMG_ROW 32
#define IMG_COL 32
#define IMG_DIM IMG_ROW*IMG_COL

#define FILT_WIN 5
#define FILT_DIM FILT_WIN*FILT_WIN

#endif